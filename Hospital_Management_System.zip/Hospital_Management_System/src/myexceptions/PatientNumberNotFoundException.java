package myexceptions;
public class PatientNumberNotFoundException extends Exception {
	public PatientNumberNotFoundException(String m) {
		super(m);
		// TODO Auto-generated constructor stub
	}
}
